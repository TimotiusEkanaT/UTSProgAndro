# UTSProgAndro
Mendesign UI aplikasi 'Safe Vault' dengan figma:
  - Design pertama : https://www.figma.com/design/WHdAtmHvaRQuxTQATaB8DG/uts-andro_project?node-id=0-1&p=f&t=El75HLjfvKeSDikg-0 
  - Design kedua (yg dipakai) : https://www.figma.com/design/AtoNoR0Rbm8TgEjP6M8vhn/SafeVault?node-id=0-1&p=f&t=bbBOHO7TKh9hRv9g-0
