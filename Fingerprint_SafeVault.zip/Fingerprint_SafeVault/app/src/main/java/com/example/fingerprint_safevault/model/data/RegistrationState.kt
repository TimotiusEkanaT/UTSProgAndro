package com.example.fingerprint_safevault.model.data

/**
 * States for the fingerprint registration process
 */
enum class RegistrationState {
    IDLE,
    READY,
    REGISTERING,
    SUCCESS,
    FAILED,
    ERROR
}