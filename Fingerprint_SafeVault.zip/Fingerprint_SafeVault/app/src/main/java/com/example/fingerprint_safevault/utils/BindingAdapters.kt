package com.example.fingerprint_safevault.utils

import android.view.View
import android.widget.TextView
import androidx.databinding.BindingAdapter

/**
 * Binding adapters for custom view attributes
 */
object BindingAdapters {
    /**
     * Sets text on a TextView
     */
    @JvmStatic
    @BindingAdapter("android:text")
    fun setText(view: TextView, text: String?) {
        view.text = text ?: ""
    }

    /**
     * Shows or hides a view based on a boolean
     */
    @JvmStatic
    @BindingAdapter("isVisible")
    fun setVisibility(view: View, isVisible: Boolean) {
        view.visibility = if (isVisible) View.VISIBLE else View.GONE
    }
}