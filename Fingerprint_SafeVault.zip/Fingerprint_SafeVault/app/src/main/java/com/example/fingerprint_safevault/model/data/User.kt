package com.example.fingerprint_safevault.model.data

/**
 * Model class representing a user
 */
data class User(
    val id: String = "",
    val isAuthenticated: Boolean = false
)