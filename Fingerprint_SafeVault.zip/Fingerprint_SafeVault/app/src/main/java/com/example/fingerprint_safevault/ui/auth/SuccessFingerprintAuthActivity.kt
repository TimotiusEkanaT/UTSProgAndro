package com.example.fingerprint_safevault.ui.auth

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.fingerprint_safevault.R
import com.example.fingerprint_safevault.ui.viewmodel.ViewModelFactory
import com.example.fingerprint_safevault.viewmodel.SuccessViewModel


class SuccessFingerprintAuthActivity : AppCompatActivity() {
    private lateinit var viewModel: SuccessViewModel
    private lateinit var authMessageText: TextView
    private lateinit var nextButton: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_success_fingerprint)

        // Initialize UI components
        authMessageText = findViewById(R.id.authmessage)
        nextButton = findViewById(R.id.rhlpe6hjsq5s)

        // Initialize ViewModel
        viewModel = ViewModelProvider(this, ViewModelFactory())[SuccessViewModel::class.java]

        // Observe success message
        viewModel.successMessage.observe(this) { message ->
            authMessageText.text = message
        }

        // Setup next button click listener
        nextButton.setOnClickListener {
            viewModel.onNextButtonClicked()
        }

        // Observe navigation events
        viewModel.navigateToNext.observe(this) { shouldNavigate ->
            if (shouldNavigate) {
                // Here you would navigate to the next screen in your app
                // For now, we'll just finish this activity
                viewModel.onNavigationComplete()
                finish()
            }
        }
    }
}