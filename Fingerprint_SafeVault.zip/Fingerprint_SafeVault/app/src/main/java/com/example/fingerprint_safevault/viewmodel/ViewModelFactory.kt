package com.example.fingerprint_safevault.ui.viewmodel

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.fingerprint_safevault.viewmodel.FingerprintViewModel
import com.example.fingerprint_safevault.viewmodel.SuccessViewModel

/**
 * Factory for creating ViewModels with dependencies
 */
class ViewModelFactory : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(FingerprintViewModel::class.java) -> {
                FingerprintViewModel() as T
            }
            modelClass.isAssignableFrom(SuccessViewModel::class.java) -> {
                SuccessViewModel() as T
            }
            modelClass.isAssignableFrom(FingerprintRegistrationViewModel::class.java) -> {
                FingerprintRegistrationViewModel(application) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }

    companion object {
        private lateinit var application: Application

        fun initialize(app: Application) {
            application = app
        }
    }
}