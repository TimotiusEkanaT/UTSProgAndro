package com.example.fingerprint_safevault.model.repository

import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.core.content.ContextCompat
import com.example.fingerprint_safevault.model.data.User
import java.util.concurrent.Executor

/**
 * Repository that handles biometric authentication
 */
class AuthRepository {
    private val _currentUser = MutableLiveData<User>()
    val currentUser: LiveData<User> = _currentUser

    // Authentication state
    private val _authState = MutableLiveData<AuthState>()
    val authState: LiveData<AuthState> = _authState

    // Biometric components
    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo

    init {
        _currentUser.value = User()
        _authState.value = AuthState.IDLE
    }

    /**
     * Initialize biometric components
     */
    fun initBiometricPrompt(
        activity: FragmentActivity,
        onAuthenticationError: (Int, CharSequence) -> Unit,
        onAuthenticationSucceeded: (BiometricPrompt.AuthenticationResult) -> Unit,
        onAuthenticationFailed: () -> Unit
    ) {
        executor = ContextCompat.getMainExecutor(activity)

        biometricPrompt = BiometricPrompt(
            activity, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    _authState.value = AuthState.ERROR
                    onAuthenticationError(errorCode, errString)
                }

                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    _currentUser.value = User(isAuthenticated = true)
                    _authState.value = AuthState.SUCCESS
                    onAuthenticationSucceeded(result)
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    _authState.value = AuthState.FAILED
                    onAuthenticationFailed()
                }
            }
        )

        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Fingerprint Authentication")
            .setSubtitle("Login using your fingerprint")
            .setNegativeButtonText("Cancel")
            .build()
    }

    /**
     * Start biometric authentication
     */
    fun authenticate() {
        _authState.value = AuthState.AUTHENTICATING
        biometricPrompt.authenticate(promptInfo)
    }

    /**
     * Reset authentication state
     */
    fun resetAuthState() {
        _authState.value = AuthState.IDLE
    }

    /**
     * Authentication states
     */
    enum class AuthState {
        IDLE,
        AUTHENTICATING,
        SUCCESS,
        FAILED,
        ERROR
    }
}