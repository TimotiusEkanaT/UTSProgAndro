package com.example.fingerprint_safevault.model.repository

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.fingerprint_safevault.model.data.FingerprintRegistration
import com.example.fingerprint_safevault.model.data.RegistrationState
import java.security.KeyStore
import java.util.concurrent.Executor
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/**
 * Repository that manages fingerprint registration
 */
class FingerprintRegistrationRepository(private val context: Context) {

    private val KEYSTORE_NAME = "AndroidKeyStore"
    private val KEY_NAME = "fingerprint_safevault_key"
    private val SHARED_PREFS_NAME = "fingerprint_prefs"
    private val KEY_FINGERPRINT_REGISTERED = "is_fingerprint_registered"
    private val KEY_FINGERPRINT_NAME = "fingerprint_name"
    private val KEY_REGISTRATION_DATE = "registration_date"

    private val sharedPreferences: SharedPreferences by lazy {
        context.getSharedPreferences(SHARED_PREFS_NAME, Context.MODE_PRIVATE)
    }

    // Registration state
    private val _registrationState = MutableLiveData<RegistrationState>()
    val registrationState: LiveData<RegistrationState> = _registrationState

    // Fingerprint registration data
    private val _fingerprintRegistration = MutableLiveData<FingerprintRegistration>()
    val fingerprintRegistration: LiveData<FingerprintRegistration> = _fingerprintRegistration

    // Biometric components
    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo

    init {
        _registrationState.value = RegistrationState.IDLE
        loadSavedFingerprint()
    }

    /**
     * Load saved fingerprint data from shared preferences
     */
    private fun loadSavedFingerprint() {
        val isRegistered = sharedPreferences.getBoolean(KEY_FINGERPRINT_REGISTERED, false)
        val name = sharedPreferences.getString(KEY_FINGERPRINT_NAME, "") ?: ""
        val date = sharedPreferences.getLong(KEY_REGISTRATION_DATE, 0)

        _fingerprintRegistration.value = FingerprintRegistration(
            isRegistered = isRegistered,
            fingerprintName = name,
            registrationDate = date
        )
    }

    /**
     * Save fingerprint registration data
     */
    private fun saveFingerprint(name: String) {
        val currentTime = System.currentTimeMillis()

        sharedPreferences.edit().apply {
            putBoolean(KEY_FINGERPRINT_REGISTERED, true)
            putString(KEY_FINGERPRINT_NAME, name)
            putLong(KEY_REGISTRATION_DATE, currentTime)
            apply()
        }

        _fingerprintRegistration.value = FingerprintRegistration(
            isRegistered = true,
            fingerprintName = name,
            registrationDate = currentTime
        )
    }

    /**
     * Check if device supports fingerprint
     */
    fun checkFingerprintAvailability(): Boolean {
        val biometricManager = BiometricManager.from(context)
        return when (biometricManager.canAuthenticate()) {
            BiometricManager.BIOMETRIC_SUCCESS -> true
            else -> false
        }
    }

    /**
     * Initialize the key for fingerprint authentication
     */
    private fun generateKey() {
        val keyStore = KeyStore.getInstance(KEYSTORE_NAME)
        keyStore.load(null)

        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_NAME
        )

        val keyGenParameterSpec = KeyGenParameterSpec.Builder(
            KEY_NAME,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_CBC)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_PKCS7)
            .setUserAuthenticationRequired(true)
            .setInvalidatedByBiometricEnrollment(true)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            keyGenParameterSpec.setUserAuthenticationParameters(
                0, KeyProperties.AUTH_BIOMETRIC_STRONG
            )
        } else {
            @Suppress("DEPRECATION")
            keyGenParameterSpec.setUserAuthenticationValidityDurationSeconds(-1)
        }

        keyGenerator.init(keyGenParameterSpec.build())
        keyGenerator.generateKey()
    }

    /**
     * Get cipher for fingerprint operations
     */
    private fun getCipher(): Cipher {
        val keyStore = KeyStore.getInstance(KEYSTORE_NAME)
        keyStore.load(null)

        val secretKey = keyStore.getKey(KEY_NAME, null) as SecretKey
        val cipher = Cipher.getInstance(
            "${KeyProperties.KEY_ALGORITHM_AES}/${KeyProperties.BLOCK_MODE_CBC}/${KeyProperties.ENCRYPTION_PADDING_PKCS7}"
        )

        cipher.init(Cipher.ENCRYPT_MODE, secretKey)
        return cipher
    }

    /**
     * Initialize registration process
     */
    fun initRegistration(
        activity: FragmentActivity,
        fingerprintName: String,
        onRegistrationSuccess: () -> Unit,
        onRegistrationError: (Int, CharSequence) -> Unit,
        onRegistrationFailed: () -> Unit
    ) {
        try {
            generateKey()

            executor = ContextCompat.getMainExecutor(context)

            biometricPrompt = BiometricPrompt(activity, executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        super.onAuthenticationError(errorCode, errString)
                        _registrationState.value = RegistrationState.ERROR
                        onRegistrationError(errorCode, errString)
                    }

                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        saveFingerprint(fingerprintName)
                        _registrationState.value = RegistrationState.SUCCESS
                        onRegistrationSuccess()
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        _registrationState.value = RegistrationState.FAILED
                        onRegistrationFailed()
                    }
                })

            promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle("Register Fingerprint")
                .setSubtitle("Place your finger on the sensor to register")
                .setNegativeButtonText("Cancel")
                .setConfirmationRequired(true)
                .build()

            _registrationState.value = RegistrationState.READY

        } catch (e: Exception) {
            _registrationState.value = RegistrationState.ERROR
            onRegistrationError(-1, "Error initializing registration: ${e.message}")
        }
    }

    /**
     * Start fingerprint registration
     */
    fun startRegistration() {
        if (_registrationState.value == RegistrationState.READY) {
            try {
                val cipher = getCipher()
                val cryptoObject = BiometricPrompt.CryptoObject(cipher)

                _registrationState.value = RegistrationState.REGISTERING
                biometricPrompt.authenticate(promptInfo, cryptoObject)
            } catch (e: Exception) {
                _registrationState.value = RegistrationState.ERROR
            }
        }
    }

    /**
     * Reset registration state
     */
    fun resetRegistrationState() {
        _registrationState.value = RegistrationState.IDLE
    }
}