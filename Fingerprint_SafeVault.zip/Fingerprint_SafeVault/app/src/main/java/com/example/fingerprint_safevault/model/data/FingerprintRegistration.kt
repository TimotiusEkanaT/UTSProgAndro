package com.example.fingerprint_safevault.model.data

/**
 * Model class representing fingerprint registration status
 */
data class FingerprintRegistration(
    val isRegistered: Boolean = false,
    val registrationDate: Long = 0,
    val fingerprintName: String = "",
    val registrationAttempts: Int = 0
)