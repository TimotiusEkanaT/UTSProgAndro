package com.example.fingerprint_safevault.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.fingerprint_safevault.R
import com.example.fingerprint_safevault.model.data.RegistrationState
import com.example.fingerprint_safevault.model.repository.FingerprintRegistrationRepository
import com.example.fingerprint_safevault.ui.viewmodel.FingerprintRegistrationViewModel

class FingerprintRegistrationActivity : AppCompatActivity() {

    private lateinit var viewModel: FingerprintRegistrationViewModel
    private lateinit var fingerprintNameEditText: EditText
    private lateinit var registerButton: Button
    private lateinit var statusTextView: TextView
    private lateinit var backBtn: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fingerprint_registration)

        // Initialize UI components
        fingerprintNameEditText = findViewById(R.id.edittext_fingerprint_name)
        registerButton = findViewById(R.id.btn_register_fingerprint)
        statusTextView = findViewById(R.id.tv_registration_status)
        backBtn = findViewById(R.id.btnback)

        // Initialize ViewModel
        viewModel = ViewModelProvider(this)[FingerprintRegistrationViewModel::class.java]

        // Setup back button
        backBtn.setOnClickListener {
            finish()
        }

        // Check if device supports fingerprint
        if (!viewModel.isFingerprintAvailable()) {
            Toast.makeText(this, "Fingerprint authentication is not available on this device", Toast.LENGTH_LONG).show()
            statusTextView.text = "Your device does not support fingerprint authentication"
            registerButton.isEnabled = false
        }

        // Setup register button
        registerButton.setOnClickListener {
            val fingerprintName = fingerprintNameEditText.text.toString().trim()
            viewModel.updateFingerprintName(fingerprintName)
            viewModel.registerFingerprint(this)
        }

        // Observe registration state
        viewModel.registrationState.observe(this) { state ->
            when (state) {
                RegistrationState.IDLE -> {
                    statusTextView.text = "Enter a name for your fingerprint and press Register"
                }
                RegistrationState.READY -> {
                    statusTextView.text = "Ready to register fingerprint"
                }
                RegistrationState.REGISTERING -> {
                    statusTextView.text = "Registering fingerprint..."
                }
                RegistrationState.SUCCESS -> {
                    statusTextView.text = "Registration successful"
                }
                RegistrationState.FAILED -> {
                    statusTextView.text = "Registration failed. Please try again."
                }
                RegistrationState.ERROR -> {
                    // Error message is handled in error observer
                }
                else -> {}
            }
        }

        // Observe error message
        viewModel.errorMessage.observe(this) { message ->
            if (message.isNotEmpty()) {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                statusTextView.text = message
                viewModel.clearErrorMessage()
            }
        }

        // Observe navigation event
        viewModel.navigateToSuccess.observe(this) { shouldNavigate ->
            if (shouldNavigate) {
                navigateToSuccessScreen()
                viewModel.onNavigationComplete()
            }
        }
    }

    private fun navigateToSuccessScreen() {
        val intent = Intent(this, SuccessFingerprintAuthActivity::class.java)
        startActivity(intent)
        finish()
    }

    override fun onPause() {
        super.onPause()
        viewModel.resetRegistrationState()
    }
}