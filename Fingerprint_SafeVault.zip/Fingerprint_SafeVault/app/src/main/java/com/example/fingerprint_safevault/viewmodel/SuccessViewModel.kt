package com.example.fingerprint_safevault.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.fingerprint_safevault.model.data.User
import com.example.fingerprint_safevault.model.repository.AuthRepository

/**
 * ViewModel for the success screen
 */
class SuccessViewModel : ViewModel() {
    private val authRepository = AuthRepository()
    
    // Success message
    private val _successMessage = MutableLiveData<String>()
    val successMessage: LiveData<String> = _successMessage
    
    // Navigation event
    private val _navigateToNext = MutableLiveData<Boolean>()
    val navigateToNext: LiveData<Boolean> = _navigateToNext
    
    init {
        _successMessage.value = "You have successfully added Fingerprint to your account"
        _navigateToNext.value = false
    }
    
    /**
     * Handle the next button click
     */
    fun onNextButtonClicked() {
        _navigateToNext.value = true
    }
    
    /**
     * Reset navigation state after navigation is handled
     */
    fun onNavigationComplete() {
        _navigateToNext.value = false
    }
}