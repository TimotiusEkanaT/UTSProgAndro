package com.example.fingerprint_safevault

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.fingerprint_safevault.model.repository.AuthRepository
import com.example.fingerprint_safevault.ui.auth.FingerprintRegistrationActivity
import com.example.fingerprint_safevault.ui.auth.SuccessFingerprintAuthActivity
import com.example.fingerprint_safevault.ui.viewmodel.ViewModelFactory
import com.example.fingerprint_safevault.viewmodel.FingerprintViewModel

class FingerprintAuthActivity : AppCompatActivity() {
    private lateinit var viewModel: FingerprintViewModel
    private lateinit var fingerprintBtn: ImageButton
    private lateinit var backBtn: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fingerprint)

        // Initialize UI components
        fingerprintBtn = findViewById(R.id.btnfingerprint)
        backBtn = findViewById(R.id.btnback)

        // Initialize ViewModel
        viewModel = ViewModelProvider(this, ViewModelFactory())[FingerprintViewModel::class.java]

        // Setup back button
        backBtn.setOnClickListener {
            finish()
        }

        // Setup button to navigate to registration screen
        findViewById<TextView>(R.id.tv_addfinger).setOnClickListener {
            val intent = Intent(this, FingerprintRegistrationActivity::class.java)
            startActivity(intent)
        }

        // Initialize biometric prompt
        viewModel.initBiometricPrompt(
            this,
            onAuthenticationError = { errorCode, errString ->
                Toast.makeText(this, "An error occurred: $errString", Toast.LENGTH_SHORT).show()
            },
            onAuthenticationSucceeded = {
                Toast.makeText(this, "Authentication Success!", Toast.LENGTH_SHORT).show()
                navigateToSuccessScreen()
            },
            onAuthenticationFailed = {
                Toast.makeText(this, "Authentication Failed!", Toast.LENGTH_SHORT).show()
            }
        )

        // Setup fingerprint button
        fingerprintBtn.setOnClickListener {
            viewModel.authenticate()
        }

        // Observe authentication state
        viewModel.authState.observe(this) { state ->
            when (state) {
                AuthRepository.AuthState.SUCCESS -> {
                    // Navigation is handled in onAuthenticationSucceeded
                }
                AuthRepository.AuthState.ERROR -> {
                    // Error is handled in onAuthenticationError
                }
                AuthRepository.AuthState.FAILED -> {
                    // Failure is handled in onAuthenticationFailed
                }
                else -> {
                    // Do nothing for other states
                }
            }
        }
    }

    private fun navigateToSuccessScreen() {
        val intent = Intent(this, SuccessFingerprintAuthActivity::class.java)
        startActivity(intent)
    }
}