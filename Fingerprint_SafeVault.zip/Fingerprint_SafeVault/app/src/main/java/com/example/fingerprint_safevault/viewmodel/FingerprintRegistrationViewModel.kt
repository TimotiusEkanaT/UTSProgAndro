package com.example.fingerprint_safevault.ui.viewmodel

import android.app.Application
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.fingerprint_safevault.model.data.FingerprintRegistration
import com.example.fingerprint_safevault.model.data.RegistrationState
import com.example.fingerprint_safevault.model.repository.FingerprintRegistrationRepository

/**
 * ViewModel for fingerprint registration
 */
class FingerprintRegistrationViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = FingerprintRegistrationRepository(application.applicationContext)

    // Registration state
    val registrationState: LiveData<RegistrationState> = repository.registrationState

    // Fingerprint registration data
    val fingerprintRegistration: LiveData<FingerprintRegistration> = repository.fingerprintRegistration

    // Fingerprint name for registration
    private val _fingerprintName = MutableLiveData<String>()
    val fingerprintName: LiveData<String> = _fingerprintName

    // Error message
    private val _errorMessage = MutableLiveData<String>()
    val errorMessage: LiveData<String> = _errorMessage

    // Navigation event
    private val _navigateToSuccess = MutableLiveData<Boolean>()
    val navigateToSuccess: LiveData<Boolean> = _navigateToSuccess

    init {
        _fingerprintName.value = ""
        _errorMessage.value = ""
        _navigateToSuccess.value = false
    }

    /**
     * Check if the device supports fingerprint
     */
    fun isFingerprintAvailable(): Boolean {
        return repository.checkFingerprintAvailability()
    }

    /**
     * Update fingerprint name
     */
    fun updateFingerprintName(name: String) {
        _fingerprintName.value = name
    }

    /**
     * Initialize and start registration process
     */
    fun registerFingerprint(activity: FragmentActivity) {
        if (_fingerprintName.value.isNullOrBlank()) {
            _errorMessage.value = "Please enter a name for your fingerprint"
            return
        }

        repository.initRegistration(
            activity = activity,
            fingerprintName = _fingerprintName.value ?: "",
            onRegistrationSuccess = {
                _navigateToSuccess.value = true
            },
            onRegistrationError = { _, errString ->
                _errorMessage.value = errString.toString()
            },
            onRegistrationFailed = {
                _errorMessage.value = "Fingerprint registration failed. Please try again."
            }
        )

        repository.startRegistration()
    }

    /**
     * Reset navigation event after navigation is handled
     */
    fun onNavigationComplete() {
        _navigateToSuccess.value = false
    }

    /**
     * Reset error message
     */
    fun clearErrorMessage() {
        _errorMessage.value = ""
    }

    /**
     * Reset registration state
     */
    fun resetRegistrationState() {
        repository.resetRegistrationState()
    }
}