package com.example.fingerprint_safevault

import android.app.Application
import com.example.fingerprint_safevault.ui.viewmodel.ViewModelFactory

/**
 * Application class for global initialization
 */
class SafeVaultApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        // Initialize the ViewModelFactory with application context
        ViewModelFactory.initialize(this)
    }

    companion object {
        // Add any application-wide constants or utilities here
    }
}