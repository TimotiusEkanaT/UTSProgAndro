package com.example.fingerprint_safevault.viewmodel

import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.fingerprint_safevault.model.data.User
import com.example.fingerprint_safevault.model.repository.AuthRepository


/**
 * ViewModel for fingerprint authentication
 */
class FingerprintViewModel : ViewModel() {
    private val authRepository = AuthRepository()

    // User data
    val currentUser: LiveData<User> = authRepository.currentUser
    
    // Authentication state
    val authState: LiveData<AuthRepository.AuthState> = authRepository.authState

    /**
     * Initialize the biometric prompt
     */
    fun initBiometricPrompt(
        activity: FragmentActivity,
        onAuthenticationError: (Int, CharSequence) -> Unit,
        onAuthenticationSucceeded: (BiometricPrompt.AuthenticationResult) -> Unit,
        onAuthenticationFailed: () -> Unit
    ) {
        authRepository.initBiometricPrompt(
            activity,
            onAuthenticationError,
            onAuthenticationSucceeded,
            onAuthenticationFailed
        )
    }

    /**
     * Start the authentication process
     */
    fun authenticate() {
        authRepository.authenticate()
    }

    /**
     * Reset the authentication state
     */
    fun resetAuthState() {
        authRepository.resetAuthState()
    }
}