package com.example.static_safevault.data.model

data class User(
    val id: String,
    val email: String,
    val hasFingerprint: Boolean = false,
    val hasFaceId: Boolean = false,
    val hasPin: Boolean = false
)