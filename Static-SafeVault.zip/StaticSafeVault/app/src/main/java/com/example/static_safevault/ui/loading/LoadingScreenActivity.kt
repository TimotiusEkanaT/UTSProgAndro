package com.example.static_safevault.ui.loading

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.static_safevault.ui.login.LoginActivity
import com.example.static_safevault.R
import com.example.static_safevault.ui.home.HomeActivity
import com.example.static_safevault.viewmodel.AuthViewModel

class LoadingScreenActivity : AppCompatActivity() {
    
    private lateinit var authViewModel: AuthViewModel
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loading_screen)
        
        authViewModel = ViewModelProvider(this).get(AuthViewModel::class.java)
        
        // Check if user is already logged in
        authViewModel.checkAuthentication()
        
        // Delay for splash screen effect
        Handler(Looper.getMainLooper()).postDelayed({
            if (authViewModel.isLoggedIn.value == true) {
                // If user is already logged in, go to home
                navigateToHome()
            } else {
                // Otherwise, go to login
                navigateToLogin()
            }
        }, 2000) // 2 second delay
    }
    
    private fun navigateToHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
    
    private fun navigateToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}