package com.example.static_safevault.ui.authentication

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.static_safevault.R
import com.example.static_safevault.ui.home.HomeActivity
import com.example.static_safevault.utils.Constants
import com.example.static_safevault.viewmodel.SecurityViewModel

class AuthenticationPinActivity : AppCompatActivity() {
    
    private lateinit var securityViewModel: SecurityViewModel
    
    private lateinit var backButton: ImageView
    private lateinit var pinEditText: EditText
    private lateinit var pinCounterTextView: TextView
    private lateinit var submitButton: LinearLayout
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_authentication_pin)
        
        // Initialize ViewModel
        securityViewModel = ViewModelProvider(this).get(SecurityViewModel::class.java)
        
        // Initialize views
        backButton = findViewById(R.id.rw2fxs4bnrvh)
        pinEditText = findViewById(R.id.rf8t42za4nwu)
        pinCounterTextView = findViewById(R.id.rt1tepzeyl9)
        submitButton = findViewById(R.id.rchqkpnufats206l)
        
        // Set up click listeners
        setupClickListeners()
        
        // Set up text watcher for PIN counter
        setupPinTextWatcher()
    }
    
    private fun setupClickListeners() {
        backButton.setOnClickListener {
            finish()
        }
        
        submitButton.setOnClickListener {
            val pin = pinEditText.text.toString()
            
            if (pin.isEmpty()) {
                Toast.makeText(this, "Please enter PIN", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            val success = securityViewModel.authenticate(SecurityViewModel.AuthType.PIN, pin)
            
            if (success) {
                val nextDestination = intent.getStringExtra(Constants.EXTRA_AUTH_TYPE) ?: ""
                when (nextDestination) {
                    "home" -> navigateToHome()
                    "hidden" -> {
                        setResult(RESULT_OK)
                        finish()
                    }
                    else -> navigateToHome()
                }
            } else {
                Toast.makeText(this, "Invalid PIN", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun setupPinTextWatcher() {
        pinEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Not needed
            }
            
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Not needed
            }
            
            override fun afterTextChanged(s: Editable?) {
                val pinLength = s?.length ?: 0
                pinCounterTextView.text = "Enter your password\n$pinLength/6"
            }
        })
    }
    
    private fun navigateToHome() {
        val intent = Intent(this, HomeActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}