package com.example.static_safevault.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

/**
 * ViewModel for handling security-related functionality
 */
class SecurityViewModel : ViewModel() {
    
    private val _fingerprintEnabled = MutableLiveData<Boolean>()
    val fingerprintEnabled: LiveData<Boolean> = _fingerprintEnabled
    
    private val _faceIdEnabled = MutableLiveData<Boolean>()
    val faceIdEnabled: LiveData<Boolean> = _faceIdEnabled
    
    private val _pinEnabled = MutableLiveData<Boolean>()
    val pinEnabled: LiveData<Boolean> = _pinEnabled
    
    private val _hiddenNotePassword = MutableLiveData<String>()
    val hiddenNotePassword: LiveData<String> = _hiddenNotePassword
    
    private val _isAuthenticated = MutableLiveData<Boolean>()
    val isAuthenticated: LiveData<Boolean> = _isAuthenticated
    
    init {
        _fingerprintEnabled.value = false
        _faceIdEnabled.value = false
        _pinEnabled.value = false
        _hiddenNotePassword.value = ""
        _isAuthenticated.value = false
    }
    
    fun enableFingerprint() {
        _fingerprintEnabled.value = true
    }
    
    fun enableFaceId() {
        _faceIdEnabled.value = true
    }
    
    fun enablePin() {
        _pinEnabled.value = true
    }
    
    fun setHiddenNotePassword(password: String) {
        _hiddenNotePassword.value = password
    }
    
    fun authenticate(type: AuthType, input: String? = null): Boolean {
        // For static implementation, any authentication will be successful
        val success = when (type) {
            AuthType.FINGERPRINT -> _fingerprintEnabled.value == true
            AuthType.FACE_ID -> _faceIdEnabled.value == true
            AuthType.PIN -> _pinEnabled.value == true && (input == "123456" || input == "000000")
            AuthType.PASSWORD -> input == _hiddenNotePassword.value
        }
        
        if (success) {
            _isAuthenticated.value = true
        }
        
        return success
    }
    
    fun resetAuthentication() {
        _isAuthenticated.value = false
    }
    
    enum class AuthType {
        FINGERPRINT,
        FACE_ID,
        PIN,
        PASSWORD
    }
}