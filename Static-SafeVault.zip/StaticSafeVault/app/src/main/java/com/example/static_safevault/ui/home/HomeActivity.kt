package com.example.static_safevault.ui.home

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.text.isDigitsOnly
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModelProvider
import com.example.static_safevault.R
import com.example.static_safevault.ui.detail.DetailActivity
import com.example.static_safevault.ui.hidden.HiddenAddSecureActivity
import com.example.static_safevault.ui.hidden.HiddenSettingOnActivity
import com.example.static_safevault.utils.Constants
import com.example.static_safevault.viewmodel.AuthViewModel
import com.example.static_safevault.viewmodel.NoteViewModel

class HomeActivity : AppCompatActivity() {

    private lateinit var noteViewModel: NoteViewModel
    
    private lateinit var searchView: SearchView
    private lateinit var addButton: ImageView
    private lateinit var editButton: ImageView
    private lateinit var noteTitle1: LinearLayout
    private lateinit var noteTitle2: LinearLayout


    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        
        // Initialize ViewModel
        noteViewModel = ViewModelProvider(this).get(NoteViewModel::class.java)
        
        // Initialize views
        searchView = findViewById(R.id.search_bar)
        addButton = findViewById(R.id.add)
        editButton = findViewById(R.id.icon_edit)
        noteTitle1 = findViewById(R.id.note_title1)
        noteTitle2 = findViewById(R.id.note_title2)
        
        // Set up observers
        setupObservers()
        
        // Set up click listeners
        setupClickListeners()
        
        // Set up search functionality
        setupSearch()
    }
    
    private fun setupObservers() {
        noteViewModel.allNotes.observe(this) { notes ->
            // In a real app, we would update a RecyclerView adapter
            // For this static implementation, we'll just use the predefined note layouts
        }
    }
    
    private fun setupClickListeners() {
        addButton.setOnClickListener {
            // In a real app, this would navigate to a create note screen
            // For this static implementation, we'll show a placeholder note
            noteViewModel.addNote("New Note", "New note content")
        }

        editButton.setOnClickListener {
            openHidden()
        }
        
        noteTitle1.setOnClickListener {
            openNoteDetail(1)
        }
        
        noteTitle2.setOnClickListener {
            openNoteDetail(2)
        }
    }
    
    private fun setupSearch() {
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let {
                    noteViewModel.searchNotes(it)
                }
                return true
            }
            
            override fun onQueryTextChange(newText: String?): Boolean {
                newText?.let {
                    if (it.isEmpty()) {
                        noteViewModel.loadNonHiddenNotes()
                    }
                    if (it.isDigitsOnly()) {
                        openHiddenNote()
                    }
                }
                return true
            }
        })
    }
    
    private fun openNoteDetail(noteId: Long) {
        val intent = Intent(this, DetailActivity::class.java)
        intent.putExtra(Constants.EXTRA_NOTE_ID, noteId)
        startActivity(intent)
    }
    private fun openHidden() {
        val intent = Intent(this, HiddenSettingOnActivity::class.java)
        startActivity(intent)
        finish()
    }
    private fun openHiddenNote() {
        val intent = Intent(this, HiddenAddSecureActivity::class.java)
        startActivity(intent)
        finish()
    }
}