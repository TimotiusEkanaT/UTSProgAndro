package com.example.static_safevault.ui.security

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.static_safevault.R
import com.example.static_safevault.viewmodel.AuthViewModel
import com.example.static_safevault.viewmodel.SecurityViewModel

class AddPinActivity : AppCompatActivity() {

    private lateinit var authViewModel: AuthViewModel
    private lateinit var securityViewModel: SecurityViewModel

    private lateinit var backButton: ImageView
    private lateinit var pinButton: LinearLayout
    private lateinit var pinTextView: TextView
    private lateinit var redTextView: TextView

    private var currentPin = ""
    private var confirmPin = ""
    private var isConfirmationStep = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_security_pin)

        // Initialize ViewModels
        authViewModel = ViewModelProvider(this).get(AuthViewModel::class.java)
        securityViewModel = ViewModelProvider(this).get(SecurityViewModel::class.java)

        // Initialize views
        backButton = findViewById(R.id.btnback)
        pinButton = findViewById(R.id.box_btn_pin)

        // Set up click listeners
        setupClickListeners()
    }

    private fun setupClickListeners() {
        backButton.setOnClickListener {
            finish()
        }

        pinButton.setOnClickListener {
            if (!isConfirmationStep) {
                // First step: Ask user to set a PIN
                showPinDialog("Set PIN")
            } else {
                // Second step: Ask user to confirm the PIN
                showPinDialog("Confirm PIN")
            }
        }

        redTextView?.setOnClickListener {
            // Navigate to add security screen (in a real app)
            Toast.makeText(this, "Navigate to security options", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showPinDialog(title: String) {
        // In a real implementation, this would show a PIN pad dialog
        // For this static demo, we'll simulate with a fake PIN "123456"

        if (!isConfirmationStep) {
            // First step
            currentPin = "123456"
            isConfirmationStep = true
            Toast.makeText(this, "Now confirm your PIN", Toast.LENGTH_SHORT).show()
        } else {
            // Confirmation step
            confirmPin = "123456"

            if (currentPin == confirmPin) {
                // PIN successfully set
                securityViewModel.enablePin()
                authViewModel.updateSecuritySettings(hasPin = true)

                Toast.makeText(this, "PIN set successfully", Toast.LENGTH_SHORT).show()
                setResult(RESULT_OK)
                finish()
            } else {
                // PINs don't match
                Toast.makeText(this, "PINs don't match. Please try again.", Toast.LENGTH_SHORT).show()

                // Reset
                currentPin = ""
                confirmPin = ""
                isConfirmationStep = false
            }
        }
    }
}