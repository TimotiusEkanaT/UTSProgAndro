package com.example.static_safevault.ui.detail

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider

import com.example.static_safevault.R
import com.example.static_safevault.utils.Constants
import com.example.static_safevault.viewmodel.NoteViewModel

class DetailActivity : AppCompatActivity() {
    
    private lateinit var noteViewModel: NoteViewModel
    
    private lateinit var titleTextView: TextView
    private lateinit var contentTextView: TextView
    private lateinit var doneButton: ImageView
    private lateinit var deleteButton: ImageView
    
    private var noteId: Long = -1
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        
        // Get note ID from intent
        noteId = intent.getLongExtra(Constants.EXTRA_NOTE_ID, -1)
        if (noteId == -1L) {
            finish()
            return
        }
        
        // Initialize ViewModel
        noteViewModel = ViewModelProvider(this).get(NoteViewModel::class.java)
        
        // Initialize views
        titleTextView = findViewById(R.id.rgfa484894d5)
        contentTextView = findViewById(R.id.r0efr0rwhqx6g)
        doneButton = findViewById(R.id.btn_done)
        deleteButton = findViewById(R.id.rvmabthcjk1n)
        
        // Load note
        noteViewModel.getNoteById(noteId)
        
        // Set up observers
        setupObservers()
        
        // Set up click listeners
        setupClickListeners()
    }
    
    private fun setupObservers() {
        noteViewModel.currentNote.observe(this) { note ->
            note?.let {
                titleTextView.text = it.title
                contentTextView.text = it.content
            } ?: run {
                // If note is null, close the activity
                finish()
            }
        }
    }
    
    private fun setupClickListeners() {
        doneButton.setOnClickListener {
            // In a real app, this would save any edits
            // For this static implementation, we'll just finish the activity
            finish()
        }
        
        deleteButton.setOnClickListener {
            showDeleteConfirmationDialog()
        }
    }
    
    private fun showDeleteConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Delete Note")
            .setMessage("Are you sure you want to delete this note?")
            .setPositiveButton("Delete") { _, _ ->
                noteViewModel.deleteNote(noteId)
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}