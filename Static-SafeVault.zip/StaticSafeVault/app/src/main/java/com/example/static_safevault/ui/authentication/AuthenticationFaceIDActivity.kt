package com.example.static_safevault.ui.authentication

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.example.static_safevault.R
import com.example.static_safevault.ui.home.HomeActivity
import com.example.static_safevault.utils.Constants
import com.example.static_safevault.viewmodel.SecurityViewModel
import java.util.concurrent.Executor

class AuthenticationFaceIDActivity : AppCompatActivity() {
    
    private lateinit var securityViewModel: SecurityViewModel
    
    private lateinit var backButton: ImageView
    private lateinit var faceIdIcon: ImageView
    
    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_authentication_face_i_d)
        
        // Initialize ViewModel
        securityViewModel = ViewModelProvider(this).get(SecurityViewModel::class.java)
        
        // Initialize views
        backButton = findViewById(R.id.rsf76y7goiea)
        faceIdIcon = findViewById(R.id.rdj7kyhinith)
        
        // Set up biometric prompt
        setupBiometricPrompt()
        
        // Set up click listeners
        setupClickListeners()
        
        // Automatically show biometric prompt
        showBiometricPrompt()
    }
    
    private fun setupBiometricPrompt() {
        executor = ContextCompat.getMainExecutor(this)
        
        biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                
                // Authentication succeeded
                securityViewModel.authenticate(SecurityViewModel.AuthType.FACE_ID)
                
                // Navigate to the next screen
                val nextDestination = intent.getStringExtra(Constants.EXTRA_AUTH_TYPE) ?: ""
                when (nextDestination) {
                    "home" -> navigateToHome()
                    "hidden" -> {
                        setResult(RESULT_OK)
                        finish()
                    }
                    else -> navigateToHome()
                }
            }
            
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                
                // Authentication error
                Toast.makeText(
                    this@AuthenticationFaceIDActivity,
                    "Authentication error: $errString", Toast.LENGTH_SHORT
                ).show()
            }
            
            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                
                // Authentication failed
                Toast.makeText(
                    this@AuthenticationFaceIDActivity,
                    "Authentication failed", Toast.LENGTH_SHORT
                ).show()
            }
        })
        
        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Face ID Authentication")
            .setSubtitle("Log in using your Face ID")
            .setNegativeButtonText("Cancel")
            .build()
    }
    
    private fun setupClickListeners() {
        backButton.setOnClickListener {
            navigateToHome()
        }
        
        faceIdIcon.setOnClickListener {
            showBiometricPrompt()
        }
    }
    
    private fun showBiometricPrompt() {
        biometricPrompt.authenticate(promptInfo)
    }
    
    private fun navigateToHome() {
        val intent = Intent(this, HomeActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }


}