package com.example.static_safevault.ui.security

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.example.static_safevault.utils.BiometricUtils
import com.example.static_safevault.R
import com.example.static_safevault.utils.Constants
import com.example.static_safevault.viewmodel.AuthViewModel
import com.example.static_safevault.viewmodel.SecurityViewModel
import java.util.concurrent.Executor

class AddFaceIDActivity : AppCompatActivity() {

    private lateinit var authViewModel: AuthViewModel
    private lateinit var securityViewModel: SecurityViewModel

    private lateinit var backButton: ImageView
    private lateinit var faceIdButton: LinearLayout
    private lateinit var faceIdEditText: EditText

    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_security_faceid)

        // Initialize ViewModels
        authViewModel = ViewModelProvider(this).get(AuthViewModel::class.java)
        securityViewModel = ViewModelProvider(this).get(SecurityViewModel::class.java)

        // Initialize views
        backButton = findViewById(R.id.btnback)
        faceIdButton = findViewById(R.id.box_btnfaceid)
        faceIdEditText = findViewById(R.id.rw5kym0dzodn)

        // Set up biometric prompt
        setupBiometricPrompt()

        // Set up click listeners
        setupClickListeners()
    }

    private fun setupBiometricPrompt() {
        executor = ContextCompat.getMainExecutor(this)

        biometricPrompt =
            BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)

                    // Enable Face ID in the app
                    securityViewModel.enableFaceId()
                    authViewModel.updateSecuritySettings(hasFaceId = true)

                    Toast.makeText(
                        this@AddFaceIDActivity,
                        "Face ID added successfully",
                        Toast.LENGTH_SHORT
                    ).show()

                    // Return to previous screen
                    setResult(RESULT_OK)
                    finish()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)

                    // Show error message
                    Toast.makeText(
                        this@AddFaceIDActivity,
                        "Authentication error: $errString", Toast.LENGTH_SHORT
                    ).show()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()

                    // Show failure message
                    Toast.makeText(
                        this@AddFaceIDActivity,
                        "Authentication failed", Toast.LENGTH_SHORT
                    ).show()
                }
            })

        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Add Face ID")
            .setSubtitle("Scan your face to add it to the app")
            .setNegativeButtonText("Cancel")
            .build()
    }

    private fun setupClickListeners() {
        backButton.setOnClickListener {
            finish()
        }

        faceIdButton.setOnClickListener {
            if (BiometricUtils.isFaceIdAvailable(this)) {
                val biometricManager = BiometricManager.from(this)
                when (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)) {
                    BiometricManager.BIOMETRIC_SUCCESS -> {
                        // Show biometric prompt
                        biometricPrompt.authenticate(promptInfo)
                    }

                    BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> {
                        Toast.makeText(
                            this,
                            "This device doesn't support Face ID authentication",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> {
                        Toast.makeText(
                            this,
                            "Biometric features are currently unavailable",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                        // Prompt the user to create credentials
                        Toast.makeText(
                            this,
                            "No Face ID enrolled. Please register your face in device settings",
                            Toast.LENGTH_SHORT
                        ).show()

                        val enrollIntent = Intent(Settings.ACTION_BIOMETRIC_ENROLL).apply {
                            putExtra(
                                Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED,
                                BiometricManager.Authenticators.BIOMETRIC_STRONG
                            )
                        }
                        startActivityForResult(enrollIntent, Constants.REQUEST_BIOMETRIC_ENROLLMENT)
                    }

                    else -> {
                        Toast.makeText(this, "Unknown error", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(
                    this,
                    "Face ID authentication is not available on this device",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == Constants.REQUEST_BIOMETRIC_ENROLLMENT && resultCode == RESULT_OK) {
            // Try again after enrollment
            faceIdButton.performClick()
        }
    }
}