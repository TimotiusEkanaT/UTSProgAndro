package com.example.static_safevault.ui.hidden

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.lifecycle.ViewModelProvider
import com.example.static_safevault.R
import com.example.static_safevault.viewmodel.NoteViewModel

class HiddenSettingOffActivity : AppCompatActivity() {
    
    private lateinit var noteViewModel: NoteViewModel
    
    private lateinit var backButton: ImageView
    private lateinit var hiddenNotesSwitch: SwitchCompat
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hidden_settingoff)
        
        // Initialize ViewModel
        noteViewModel = ViewModelProvider(this).get(NoteViewModel::class.java)
        
        // Initialize views
        backButton = findViewById(R.id.btnback)
        hiddenNotesSwitch = findViewById(R.id.switch_hidden_notes)
        
        // Set up click listeners
        setupClickListeners()
        
        // Initialize switch state
        hiddenNotesSwitch.isChecked = false
    }
    
    private fun setupClickListeners() {
        backButton.setOnClickListener {
            finish()
        }
        
        hiddenNotesSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                // Navigate to Hidden Notes Setting On screen
                val intent = Intent(this, HiddenSettingOnActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}