package com.example.static_safevault.ui.hidden

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.static_safevault.R
import com.example.static_safevault.ui.authentication.AuthenticationFaceIDActivity
import com.example.static_safevault.ui.authentication.AuthenticationFingerprintActivity
import com.example.static_safevault.ui.authentication.AuthenticationPinActivity
import com.example.static_safevault.ui.home.HomeActivity
import com.example.static_safevault.ui.security.AddFaceIDActivity
import com.example.static_safevault.ui.security.AddFingerprintActivity
import com.example.static_safevault.ui.security.AddPinActivity
import com.example.static_safevault.utils.Constants
import com.example.static_safevault.viewmodel.NoteViewModel
import com.example.static_safevault.viewmodel.SecurityViewModel

class HiddenAddSecureActivity : AppCompatActivity() {
    
    private lateinit var securityViewModel: SecurityViewModel
    private lateinit var noteViewModel: NoteViewModel
    
    private lateinit var backButton: ImageView
    private lateinit var passwordEditText: EditText
    private lateinit var fingerprintLayout: LinearLayout
    private lateinit var faceIdLayout: LinearLayout
    private lateinit var pinLayout: LinearLayout
    
    private val REQUEST_FINGERPRINT_AUTH = 101
    private val REQUEST_FACE_ID_AUTH = 102
    private val REQUEST_PIN_AUTH = 103
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hidden_addsecure)
        
        // Initialize ViewModels
        securityViewModel = ViewModelProvider(this).get(SecurityViewModel::class.java)
        noteViewModel = ViewModelProvider(this).get(NoteViewModel::class.java)
        
        // Initialize views
        backButton = findViewById(R.id.btnback)
        passwordEditText = findViewById(R.id.ed_pwd_hiddennote)
        fingerprintLayout = findViewById(R.id.rze46lrlgbai)
        faceIdLayout = findViewById(R.id.box_hiddennote_faceid)
        pinLayout = findViewById(R.id.box_hiddennote_pin)
        
        // Set up click listeners
        setupClickListeners()
    }
    
    private fun setupClickListeners() {
        backButton.setOnClickListener {
            home()
        }
        faceIdLayout.setOnClickListener {
            face()
        }
        fingerprintLayout.setOnClickListener {
            finger()
        }
        pinLayout.setOnClickListener {
            pin()
        }

        
        passwordEditText.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val password = passwordEditText.text.toString()
                if (password.isNotEmpty()) {
                    val authenticated = securityViewModel.authenticate(
                        SecurityViewModel.AuthType.PASSWORD,
                        password
                    )
                    
                    if (authenticated) {
                        accessHiddenNotes()
                    } else {
                        Toast.makeText(this, "Invalid password", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
    
    private fun accessHiddenNotes() {
        // Enable hidden notes
        noteViewModel.setHiddenNoteEnabled(true)
        
        // In a real app, this would navigate to the hidden notes screen
        Toast.makeText(this, "Hidden notes accessed", Toast.LENGTH_SHORT).show()
        
        // Return to the previous screen (likely the home screen)
        setResult(RESULT_OK)
        finish()
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (resultCode == RESULT_OK) {
            when (requestCode) {
                REQUEST_FINGERPRINT_AUTH, REQUEST_FACE_ID_AUTH, REQUEST_PIN_AUTH -> {
                    // Authentication successful
                    accessHiddenNotes()
                }
            }
        }

    }
    private fun home() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()
    }
    private fun pin() {
        val intent = Intent(this, AddPinActivity::class.java)
        startActivity(intent)
        finish()
    }
    private fun finger() {
        val intent = Intent(this, AddFingerprintActivity::class.java)
        startActivity(intent)
        finish()
    }
    private fun face() {
        val intent = Intent(this, AddFaceIDActivity::class.java)
        startActivity(intent)
        finish()
    }
}