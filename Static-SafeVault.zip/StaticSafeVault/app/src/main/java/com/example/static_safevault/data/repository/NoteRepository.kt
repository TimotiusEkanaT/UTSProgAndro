package com.example.static_safevault.data.repository

import com.example.static_safevault.data.model.Note

/**
 * Repository for handling notes-related operations
 */
class NoteRepository {
    
    // In-memory storage for notes
    private val notes = mutableListOf<Note>()
    
    // For demonstration, initialize with sample notes
    init {
        notes.add(Note(1, "Title 1", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\nDuis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.\nExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."))
        notes.add(Note(2, "Title 2", "Details about title 2..."))
    }
    
    fun getAllNotes(): List<Note> {
        return notes.toList()
    }
    
    fun getNonHiddenNotes(): List<Note> {
        return notes.filter { !it.isHidden }
    }
    
    fun getHiddenNotes(): List<Note> {
        return notes.filter { it.isHidden }
    }
    
    fun getNoteById(id: Long): Note? {
        return notes.find { it.id == id }
    }
    
    fun addNote(title: String, content: String, isHidden: Boolean = false): Note {
        val maxId = notes.maxByOrNull { it.id }?.id ?: 0
        val newNote = Note(
            id = maxId + 1,
            title = title,
            content = content,
            isHidden = isHidden
        )
        notes.add(newNote)
        return newNote
    }
    
    fun updateNote(id: Long, title: String? = null, content: String? = null, isHidden: Boolean? = null): Boolean {
        val index = notes.indexOfFirst { it.id == id }
        if (index != -1) {
            val note = notes[index]
            notes[index] = note.copy(
                title = title ?: note.title,
                content = content ?: note.content,
                isHidden = isHidden ?: note.isHidden,
                updatedAt = System.currentTimeMillis()
            )
            return true
        }
        return false
    }
    
    fun deleteNote(id: Long): Boolean {
        val index = notes.indexOfFirst { it.id == id }
        if (index != -1) {
            notes.removeAt(index)
            return true
        }
        return false
    }
    
    fun searchNotes(query: String): List<Note> {
        if (query.isEmpty()) {
            return getNonHiddenNotes()
        }
        
        return notes.filter { note ->
            !note.isHidden && (note.title.contains(query, true) || note.content.contains(query, true))
        }
    }
}