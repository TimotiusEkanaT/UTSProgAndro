package com.example.static_safevault.ui.hidden

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.lifecycle.ViewModelProvider
import com.example.static_safevault.R
import com.example.static_safevault.ui.home.HomeActivity
import com.example.static_safevault.viewmodel.NoteViewModel
import com.example.static_safevault.viewmodel.SecurityViewModel

class HiddenSettingOnActivity : AppCompatActivity() {
    
    private lateinit var noteViewModel: NoteViewModel
    private lateinit var securityViewModel: SecurityViewModel
    
    private lateinit var backButton: ImageView
    private lateinit var passwordEditText: EditText
    private lateinit var hiddenNotesSwitch: SwitchCompat
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hidden_settingon)
        
        // Initialize ViewModels
        noteViewModel = ViewModelProvider(this).get(NoteViewModel::class.java)
        securityViewModel = ViewModelProvider(this).get(SecurityViewModel::class.java)
        
        // Initialize views
        backButton = findViewById(R.id.btnback)
        passwordEditText = findViewById(R.id.box_hiddennote_pwd)
        hiddenNotesSwitch = findViewById(R.id.switch_hidden_notes)
        
        // Set up click listeners
        setupClickListeners()
        
        // Initialize switch state
        hiddenNotesSwitch.isChecked = true
    }
    
    private fun setupClickListeners() {
        backButton.setOnClickListener {
            home()
        }
        
        hiddenNotesSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (!isChecked) {
                // Navigate to Hidden Notes Setting Off screen
                val intent = Intent(this, HiddenSettingOffActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
        
        // When the user leaves the password edit text, save the password
        passwordEditText.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val password = passwordEditText.text.toString()
                if (password.isNotEmpty()) {
                    securityViewModel.setHiddenNotePassword(password)
                    noteViewModel.setHiddenNoteEnabled(true)
                    Toast.makeText(this, "Hidden notes password set", Toast.LENGTH_SHORT).show()
                }

            }
        }


    }
    private fun home() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()
    }
}