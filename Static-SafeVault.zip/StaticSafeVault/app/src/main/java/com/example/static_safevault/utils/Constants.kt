package com.example.static_safevault.utils

/**
 * Constants used throughout the application
 */
object Constants {
    // Shared Preferences
    const val PREF_NAME = "SaveVaultPreferences"
    const val PREF_IS_LOGGED_IN = "isLoggedIn"
    const val PREF_HIDDEN_NOTE_ENABLED = "hiddenNoteEnabled"
    const val PREF_FINGERPRINT_ENABLED = "fingerprintEnabled"
    const val PREF_FACE_ID_ENABLED = "faceIdEnabled"
    const val PREF_PIN_ENABLED = "pinEnabled"
    
    // Intent extras
    const val EXTRA_NOTE_ID = "note_id"
    const val EXTRA_AUTH_TYPE = "auth_type"
    
    // Request codes
    const val REQUEST_BIOMETRIC_ENROLLMENT = 1001
    const val REQUEST_ADD_FINGERPRINT = 1002
    const val REQUEST_ADD_FACE_ID = 1003
    const val REQUEST_ADD_PIN = 1004
    
    // Authentication types
    const val AUTH_TYPE_FINGERPRINT = "fingerprint"
    const val AUTH_TYPE_FACE_ID = "face_id"
    const val AUTH_TYPE_PIN = "pin"
}