package com.example.static_safevault.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.static_safevault.data.model.User
import com.example.static_safevault.data.repository.AuthRepository

class AuthViewModel : ViewModel() {
    
    private val authRepository = AuthRepository()
    
    private val _currentUser = MutableLiveData<User?>()
    val currentUser: LiveData<User?> = _currentUser
    
    private val _isLoggedIn = MutableLiveData<Boolean>()
    val isLoggedIn: LiveData<Boolean> = _isLoggedIn
    
    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage

    init {
        _isLoggedIn.value = false
        _errorMessage.value = null
    }
    
    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _errorMessage.value = "Email and password cannot be empty"
            return
        }
        
        val success = authRepository.login(email, password)
        if (success) {
            _currentUser.value = authRepository.getCurrentUser()
            _isLoggedIn.value = true
            _errorMessage.value = null
        } else {
            _errorMessage.value = "Invalid credentials"
        }
    }
    
    fun loginWithGoogle() {
        val success = authRepository.loginWithGoogle()
        if (success) {
            _currentUser.value = authRepository.getCurrentUser()
            _isLoggedIn.value = true
            _errorMessage.value = null
        } else {
            _errorMessage.value = "Google sign-in failed"
        }
    }
    
    fun logout() {
        authRepository.logout()
        _currentUser.value = null
        _isLoggedIn.value = false
    }
    
    fun updateSecuritySettings(hasFingerprint: Boolean? = null, hasFaceId: Boolean? = null, hasPin: Boolean? = null) {
        val success = authRepository.updateUserSecuritySettings(hasFingerprint, hasFaceId, hasPin)
        if (success) {
            _currentUser.value = authRepository.getCurrentUser()
        }
    }
    
    fun checkAuthentication() {
        _isLoggedIn.value = authRepository.isAuthenticated()
        _currentUser.value = authRepository.getCurrentUser()
    }
    
    fun clearErrorMessage() {
        _errorMessage.value = null
    }
}