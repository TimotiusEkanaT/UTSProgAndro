package com.example.static_safevault.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.static_safevault.data.model.Note
import com.example.static_safevault.data.repository.NoteRepository

class NoteViewModel : ViewModel() {
    
    private val noteRepository = NoteRepository()
    
    private val _allNotes = MutableLiveData<List<Note>>()
    val allNotes: LiveData<List<Note>> = _allNotes
    
    private val _currentNote = MutableLiveData<Note?>()
    val currentNote: LiveData<Note?> = _currentNote
    
    private val _isHiddenNoteEnabled = MutableLiveData<Boolean>()
    val isHiddenNoteEnabled: LiveData<Boolean> = _isHiddenNoteEnabled
    
    init {
        loadNonHiddenNotes()
        _isHiddenNoteEnabled.value = false
    }
    
    fun loadNonHiddenNotes() {
        _allNotes.value = noteRepository.getNonHiddenNotes()
    }
    
    fun loadHiddenNotes() {
        _allNotes.value = noteRepository.getHiddenNotes()
    }
    
    fun loadAllNotes() {
        _allNotes.value = noteRepository.getAllNotes()
    }
    
    fun getNoteById(id: Long) {
        _currentNote.value = noteRepository.getNoteById(id)
    }
    
    fun addNote(title: String, content: String, isHidden: Boolean = false) {
        if (title.isBlank()) {
            // Don't add notes with empty titles
            return
        }
        
        val newNote = noteRepository.addNote(title, content, isHidden)
        
        // Refresh the notes list
        if (isHidden) {
            if (_isHiddenNoteEnabled.value == true) {
                loadHiddenNotes()
            }
        } else {
            loadNonHiddenNotes()
        }
    }
    
    fun updateNote(id: Long, title: String? = null, content: String? = null, isHidden: Boolean? = null) {
        val success = noteRepository.updateNote(id, title, content, isHidden)
        
        if (success) {
            // Refresh the current note if it was updated
            if (_currentNote.value?.id == id) {
                _currentNote.value = noteRepository.getNoteById(id)
            }
            
            // Refresh the notes list
            if (_isHiddenNoteEnabled.value == true) {
                loadHiddenNotes()
            } else {
                loadNonHiddenNotes()
            }
        }
    }
    
    fun deleteNote(id: Long) {
        val success = noteRepository.deleteNote(id)
        
        if (success) {
            // Clear the current note if it was deleted
            if (_currentNote.value?.id == id) {
                _currentNote.value = null
            }
            
            // Refresh the notes list
            if (_isHiddenNoteEnabled.value == true) {
                loadHiddenNotes()
            } else {
                loadNonHiddenNotes()
            }
        }
    }
    
    fun searchNotes(query: String) {
        _allNotes.value = noteRepository.searchNotes(query)
    }
    
    fun setHiddenNoteEnabled(enabled: Boolean) {
        _isHiddenNoteEnabled.value = enabled
        if (enabled) {
            loadHiddenNotes()
        } else {
            loadNonHiddenNotes()
        }
    }
    
    fun clearCurrentNote() {
        _currentNote.value = null
    }
}