package com.example.static_safevault.ui.login

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider

import com.example.static_safevault.ui.home.HomeActivity
import com.example.static_safevault.R
import com.example.static_safevault.viewmodel.AuthViewModel

class LoginActivity : AppCompatActivity() {

    private lateinit var authViewModel: AuthViewModel

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: LinearLayout
    private lateinit var signInButton: LinearLayout
    private lateinit var googleLoginButton: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Initialize ViewModel
        authViewModel = ViewModelProvider(this).get(AuthViewModel::class.java)

        // Initialize views
        emailEditText = findViewById(R.id.email)
        passwordEditText = findViewById(R.id.rp63f2h6fjfl) // Using the ID from the layout
        loginButton = findViewById(R.id.btn_biru_login)
        signInButton = findViewById(R.id.btn_sign_in)
        googleLoginButton = findViewById(R.id.icon_google)

        // Set up observers
        setupObservers()

        // Set up click listeners
        setupClickListeners()
    }

    private fun setupObservers() {
        authViewModel.isLoggedIn.observe(this) { isLoggedIn ->
            if (isLoggedIn) {
                navigateToHome()
            }
        }

        authViewModel.errorMessage.observe(this) { errorMessage ->
            errorMessage?.let {
                Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
                authViewModel.clearErrorMessage()
            }
        }
    }

    private fun setupClickListeners() {
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()
            authViewModel.login(email, password)
        }

        signInButton.setOnClickListener {
            // For static implementation, we'll just show a message
            Toast.makeText(this, "Sign-in functionality not implemented in static demo", Toast.LENGTH_SHORT).show()
        }

        googleLoginButton.setOnClickListener {
            authViewModel.loginWithGoogle()
        }
    }

    private fun navigateToHome() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()
    }
}