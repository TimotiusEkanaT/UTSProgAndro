package com.example.static_safevault.data.repository

import com.example.static_safevault.data.model.User

/**
 * Repository for handling authentication-related operations
 */
class AuthRepository {
    
    private var currentUser: User? = null
    
    fun login(email: String, password: String): Boolean {
        // In a real app, this would validate against a database or API
        // For this static implementation, we'll accept any input
        currentUser = User(
            id = "user_${System.currentTimeMillis()}",
            email = email,
            hasFingerprint = false,
            hasFaceId = false,
            hasPin = false
        )
        return true
    }
    
    fun loginWithGoogle(): Boolean {
        // In a real app, this would handle Google Sign In
        currentUser = User(
            id = "google_user_${System.currentTimeMillis()}",
            email = "google_user@example.com",
            hasFingerprint = false,
            hasFaceId = false,
            hasPin = false
        )
        return true
    }
    
    fun getCurrentUser(): User? {
        return currentUser
    }
    
    fun logout() {
        currentUser = null
    }
    
    fun updateUserSecuritySettings(hasFingerprint: Boolean? = null, hasFaceId: Boolean? = null, hasPin: Boolean? = null): Boolean {
        currentUser?.let { user ->
            currentUser = user.copy(
                hasFingerprint = hasFingerprint ?: user.hasFingerprint,
                hasFaceId = hasFaceId ?: user.hasFaceId,
                hasPin = hasPin ?: user.hasPin
            )
            return true
        }
        return false
    }
    
    fun isAuthenticated(): Boolean {
        return currentUser != null
    }
}